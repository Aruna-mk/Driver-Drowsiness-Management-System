import tkinter as tk
from driver_gui import DriverDrowsinessGUI

if __name__ == "__main__":
    root = tk.Tk()
    app = DriverDrowsinessGUI(root)
    root.mainloop()

































"""
#driver_gui.py when i press start journey button the camera is on the face or detected but the drowsiness is not detected. the code #detect_drowsiness.py is detecting the drowsiness correctly please apply the code into #driver_gui.py to work correctly
"""